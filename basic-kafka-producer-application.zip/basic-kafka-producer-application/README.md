
    Unit test - Isolated  
               - Pipe
               - Service
               - Component
                      - Two choice
                                  1. Construct the component instance manually and provide it with service object which are provided with some other service objects
                                    HeroesComponent - Own (test)
                                    HelloService - Own  (external to that component)
                                    HttpClient - Angular API
                                            Observable get()

                Solution - Mock the external dependencies
                                 Mocking is a process of provide fake behaviour for external components

                                     jasmine.createSpyObj();

                                  2. Ask the Angular testing framework will load the component and provide service object
                  
            subscribe()


    To ignore a test case during execution - Xit(){..}
   
  fit() -> it will execute only that test case 

               